# matrix_resolver.py
matrix_resolver_content = '''"""
Matrix Resolver - Handle GitHub Actions matrix variable resolution
"""

import re
import os
from typing import Dict, Any


class MatrixResolver:
    def __init__(self):
        self.expression_pattern = re.compile(r'\\$\\{\\{\\s*([^}]+)\\s*\\}\\}')
    
    def resolve_container_image(self, image_template: str, matrix_vars: Dict) -> str:
        """Resolve matrix variables in container image"""
        if not image_template:
            return 'ubuntu:latest'
        
        # Handle GitHub Actions expressions
        resolved_image = self._resolve_expressions(image_template, matrix_vars)
        return resolved_image
    
    def resolve_command(self, command: str, matrix_vars: Dict, env_vars: Dict = None) -> str:
        """Resolve variables in commands"""
        if not command:
            return ''
        
        # Combine matrix vars and env vars
        all_vars = matrix_vars.copy()
        if env_vars:
            all_vars.update({'env': env_vars})
        
        return self._resolve_expressions(command, all_vars)
    
    def resolve_step_env(self, env_config: Dict, matrix_vars: Dict) -> Dict[str, str]:
        """Resolve environment variables for a step"""
        resolved_env = {}
        
        for key, value in env_config.items():
            if isinstance(value, str):
                resolved_env[key] = self._resolve_expressions(value, matrix_vars)
            else:
                resolved_env[key] = str(value)
        
        return resolved_env
    
    def _resolve_expressions(self, text: str, context: Dict) -> str:
        """Resolve GitHub Actions expressions like ${{ matrix.variable }}"""
        def replace_expression(match):
            expression = match.group(1).strip()
            return self._evaluate_expression(expression, context)
        
        return self.expression_pattern.sub(replace_expression, text)
    
    def _evaluate_expression(self, expression: str, context: Dict) -> str:
        """Evaluate a GitHub Actions expression"""
        # Handle matrix variables
        if expression.startswith('matrix.'):
            var_name = expression[7:]  # Remove 'matrix.'
            return str(context.get(var_name, f'UNDEFINED_MATRIX_{var_name}'))
        
        # Handle env variables
        if expression.startswith('env.'):
            var_name = expression[4:]  # Remove 'env.'
            env_vars = context.get('env', {})
            if isinstance(env_vars, dict):
                return str(env_vars.get(var_name, f'UNDEFINED_ENV_{var_name}'))
            else:
                return str(os.getenv(var_name, f'UNDEFINED_ENV_{var_name}'))
        
        # Handle functions
        if 'contains(' in expression:
            return self._evaluate_contains(expression, context)
        
        if 'always()' in expression:
            return 'true'
        
        if 'success()' in expression:
            return 'true'  # Default assumption
        
        if 'failure()' in expression:
            return 'false'  # Default assumption
        
        # Handle simple boolean logic
        if expression in ['true', 'false']:
            return expression
        
        # Default: return as string
        return expression
    
    def _evaluate_contains(self, expression: str, context: Dict) -> str:
        """Evaluate contains() function"""
        # Simple regex to extract contains(haystack, needle)
        contains_match = re.match(r'contains\\(([^,]+),\\s*[\\'\\"]*([^\\'\\"\\)]+)[\\'\\"]*\\)', expression)
        if contains_match:
            haystack_expr = contains_match.group(1).strip()
            needle = contains_match.group(2).strip()
            
            # Resolve haystack expression
            haystack = self._evaluate_expression(haystack_expr, context)
            
            # Check if needle is in haystack
            return 'true' if needle in haystack else 'false'
        
        return 'false'
    
    def build_matrix_env_vars(self, matrix_vars: Dict) -> Dict[str, str]:
        """Build environment variables from matrix configuration"""
        env_vars = {}
        
        # Add matrix variables with MATRIX_ prefix
        for key, value in matrix_vars.items():
            env_var_name = f'MATRIX_{key.upper()}'
            env_vars[env_var_name] = str(value)
        
        return env_vars
    
    def resolve_conditional(self, condition: str, context: Dict) -> bool:
        """Resolve if conditions for steps and jobs"""
        if not condition or condition.strip() == 'true':
            return True
        
        if condition.strip() == 'false':
            return False
        
        # Resolve expressions in condition
        resolved_condition = self._resolve_expressions(condition, context)
        
        # Simple boolean evaluation
        if resolved_condition.lower() in ['true', '1']:
            return True
        elif resolved_condition.lower() in ['false', '0']:
            return False
        else:
            # Default to true for complex expressions we can't evaluate
            return True
'''

with open("amd_ci/core/matrix_resolver.py", "w") as f:
    f.write(matrix_resolver_content)

print("matrix_resolver.py created!")