# Write setup.py
setup_content = '''"""
AMD CI - Distributed GPU CI/CD System
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="amd-ci",
    version="0.1.0",
    author="AMD CI Team",
    author_email="ci-team@amd.com",
    description="Distributed CI/CD system for AMD GPU workloads",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/amd/amd-ci",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "kubernetes": ["kubernetes>=24.0.0"],
        "dashboard": ["fastapi>=0.68.0", "uvicorn>=0.15.0", "jinja2>=3.0.0"],
        "dev": ["pytest>=6.0", "black>=21.0", "flake8>=3.9"],
    },
    entry_points={
        "console_scripts": [
            "amd-ci=amd_ci.cli.main:main",
            "amd-ci-watcher=amd_ci.watcher.git_watcher:main",
            "amd-ci-dashboard=amd_ci.monitoring.dashboard:main",
        ],
    },
    include_package_data=True,
    package_data={
        "amd_ci": ["templates/*.html", "static/*"],
    },
)
'''

with open("setup.py", "w") as f:
    f.write(setup_content)

# Write requirements.txt
requirements_content = '''# Core dependencies
pyyaml>=6.0
asyncio-subprocess>=0.1.0
aiofiles>=0.8.0
click>=8.0.0

# Git integration
gitpython>=3.1.0

# Container support
docker>=6.0.0

# HTTP client for webhooks
aiohttp>=3.8.0

# Database/state management
redis>=4.0.0
sqlalchemy>=1.4.0
alembic>=1.7.0

# Optional dependencies (install via extras)
# kubernetes>=24.0.0  # for k8s execution
# fastapi>=0.68.0     # for dashboard
# uvicorn>=0.15.0     # for dashboard server
# jinja2>=3.0.0       # for templating

# Development dependencies
# pytest>=6.0
# black>=21.0
# flake8>=3.9
'''

with open("requirements.txt", "w") as f:
    f.write(requirements_content)

print("Setup files created!")