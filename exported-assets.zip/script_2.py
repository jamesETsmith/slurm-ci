# Write package __init__.py
init_content = '''"""
AMD CI - Distributed CI/CD System for AMD GPU Workloads

A GitHub Actions compatible CI/CD system designed for AMD GPU clusters.
"""

__version__ = "0.1.0"
__author__ = "AMD CI Team"

from .core.orchestrator import WorkflowOrchestrator, LocalOrchestrator
from .core.workflow_parser import WorkflowParser
from .core.matrix_resolver import MatrixResolver

__all__ = [
    "WorkflowOrchestrator",
    "LocalOrchestrator", 
    "WorkflowParser",
    "MatrixResolver",
]
'''

with open("amd_ci/__init__.py", "w") as f:
    f.write(init_content)

print("Main package __init__.py created!")