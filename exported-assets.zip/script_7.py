# Create execution module files

# kubernetes_runner.py
k8s_runner_content = '''"""
Kubernetes Job Runner - Execute workflows as Kubernetes Jobs
"""

from kubernetes import client, config
from kubernetes.client.rest import ApiException
from typing import Dict, List
import logging


logger = logging.getLogger(__name__)


class KubernetesJobRunner:
    def __init__(self, k8s_config: Dict):
        self.config = k8s_config
        
        # Load Kubernetes config
        if k8s_config.get('in_cluster', False):
            config.load_incluster_config()
        else:
            config.load_kube_config(k8s_config.get('kubeconfig_path'))
        
        self.batch_v1 = client.BatchV1Api()
        self.core_v1 = client.CoreV1Api()
    
    async def submit_job(self, job_spec: Dict) -> str:
        """Submit workflow as Kubernetes Job"""
        
        job_name = f"ci-{job_spec['job_name']}-{job_spec['job_id'][:8]}"
        container_spec = job_spec['container']
        matrix_vars = job_spec.get('matrix_vars', {})
        
        # Create Job manifest
        job_manifest = {
            'apiVersion': 'batch/v1',
            'kind': 'Job',
            'metadata': {
                'name': job_name,
                'labels': {
                    'workflow-id': job_spec.get('workflow_id', ''),
                    'job-name': job_spec['job_name'],
                    'gpu-arch': matrix_vars.get('gpu_arch', 'none')
                }
            },
            'spec': {
                'template': {
                    'spec': {
                        'containers': [{
                            'name': 'workflow-runner',
                            'image': container_spec['image'],
                            'command': ['/bin/bash', '-c'],
                            'args': [self._build_workflow_script(job_spec)],
                            'env': self._build_env_vars(job_spec),
                            'resources': {
                                'limits': {
                                    'amd.com/gpu': '1'  # AMD GPU resource
                                },
                                'requests': {
                                    'memory': '8Gi',
                                    'cpu': '4'
                                }
                            },
                            'volumeMounts': [{
                                'name': 'workspace',
                                'mountPath': '/workspace'
                            }]
                        }],
                        'volumes': [{
                            'name': 'workspace',
                            'emptyDir': {}
                        }],
                        'restartPolicy': 'Never',
                        'nodeSelector': self._build_node_selector(matrix_vars)
                    }
                },
                'backoffLimit': 3,
                'ttlSecondsAfterFinished': 3600  # Clean up after 1 hour
            }
        }
        
        # Create the job
        try:
            job = self.batch_v1.create_namespaced_job(
                namespace=self.config.get('namespace', 'default'),
                body=job_manifest
            )
            logger.info(f"Created Kubernetes job: {job.metadata.name}")
            return job.metadata.name
            
        except ApiException as e:
            logger.error(f"Failed to create job: {e}")
            raise
    
    def _build_workflow_script(self, job_spec: Dict) -> str:
        """Build the complete workflow execution script"""
        script_lines = [
            '#!/bin/bash',
            'set -e',  # Exit on error
            'set -x',  # Print commands
            '',
            '# Setup workspace',
            f'git clone {job_spec["repo_url"]} /workspace',
            'cd /workspace',
            f'git checkout {job_spec["commit_hash"]}',
            '',
            '# Execute workflow steps'
        ]
        
        for i, step in enumerate(job_spec['steps']):
            step_name = step.get('name', f'Step {i+1}')
            script_lines.extend([
                f'',
                f'echo "::group::{step_name}"',
                f'echo "Running step: {step_name}"',
                step['run'],
                f'echo "::endgroup::"',
                f'echo "✓ {step_name} completed"',
                ''
            ])
        
        return '\\n'.join(script_lines)
    
    def _build_env_vars(self, job_spec: Dict) -> List[Dict]:
        """Build environment variables for container"""
        env_vars = []
        
        # Add job environment variables
        for key, value in job_spec.get('env', {}).items():
            env_vars.append({'name': key, 'value': str(value)})
        
        # Add matrix variables
        for key, value in job_spec.get('matrix_vars', {}).items():
            env_vars.append({'name': f'MATRIX_{key.upper()}', 'value': str(value)})
        
        # Add GitHub Actions compatible vars
        env_vars.extend([
            {'name': 'GITHUB_WORKSPACE', 'value': '/workspace'},
            {'name': 'GITHUB_SHA', 'value': job_spec.get('commit_hash', '')},
            {'name': 'GITHUB_REF', 'value': job_spec.get('branch', '')},
            {'name': 'CI', 'value': 'true'},
            {'name': 'GITHUB_ACTIONS', 'value': 'true'}
        ])
        
        return env_vars
    
    def _build_node_selector(self, matrix_vars: Dict) -> Dict:
        """Build node selector based on matrix variables"""
        selector = {}
        
        # GPU architecture selection
        if 'gpu_arch' in matrix_vars:
            selector['gpu.amd.com/chip'] = matrix_vars['gpu_arch']
        
        return selector
    
    async def get_job_status(self, job_name: str) -> Dict:
        """Get status of a Kubernetes job"""
        try:
            job = self.batch_v1.read_namespaced_job(
                name=job_name,
                namespace=self.config.get('namespace', 'default')
            )
            
            conditions = job.status.conditions or []
            status = 'running'
            
            for condition in conditions:
                if condition.type == 'Complete' and condition.status == 'True':
                    status = 'success'
                elif condition.type == 'Failed' and condition.status == 'True':
                    status = 'failed'
            
            return {
                'status': status,
                'active': job.status.active or 0,
                'succeeded': job.status.succeeded or 0,
                'failed': job.status.failed or 0
            }
            
        except ApiException as e:
            logger.error(f"Failed to get job status: {e}")
            return {'status': 'unknown', 'error': str(e)}
    
    async def get_job_logs(self, job_name: str) -> str:
        """Get logs from a Kubernetes job"""
        try:
            # Find pod for this job
            pods = self.core_v1.list_namespaced_pod(
                namespace=self.config.get('namespace', 'default'),
                label_selector=f'job-name={job_name}'
            )
            
            if not pods.items:
                return "No pods found for job"
            
            pod_name = pods.items[0].metadata.name
            
            # Get pod logs
            logs = self.core_v1.read_namespaced_pod_log(
                name=pod_name,
                namespace=self.config.get('namespace', 'default')
            )
            
            return logs
            
        except ApiException as e:
            logger.error(f"Failed to get job logs: {e}")
            return f"Error retrieving logs: {e}"
'''

with open("amd_ci/execution/kubernetes_runner.py", "w") as f:
    f.write(k8s_runner_content)

print("kubernetes_runner.py created!")