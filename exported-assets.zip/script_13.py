# Create example workflow files and README

# Example CI workflow
ci_workflow_content = '''name: AMD GPU CI Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]
  workflow_dispatch:
  schedule:
    - cron: '0 2 * * *'

env:
  ROCM_VERSION: 5.7.0

jobs:
  build-and-test:
    runs-on: self-hosted
    container:
      image: rocm/dev-ubuntu-22.04:${{ matrix.rocm_version }}
      
    strategy:
      fail-fast: false
      max-parallel: 8
      matrix:
        gpu_arch: [gfx908, gfx90a, gfx1030]
        rocm_version: [5.6.0, 5.7.0]
        build_type: [Release, Debug]
        exclude:
          - gpu_arch: gfx1030
            build_type: Debug
            
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        with:
          submodules: recursive
          
      - name: Setup ROCm environment
        run: |
          apt-get update && apt-get install -y \\
            build-essential cmake ninja-build python3-dev
          
          pip install torch --index-url https://download.pytorch.org/whl/rocm${{ matrix.rocm_version }}
          
      - name: Configure build
        run: |
          cmake -S . -B build -GNinja \\
            -DCMAKE_BUILD_TYPE=${{ matrix.build_type }} \\
            -DGPU_TARGETS=${{ matrix.gpu_arch }}
            
      - name: Build project
        run: |
          cd build
          ninja -j$(nproc)
          
      - name: Run tests
        run: |
          cd build
          export HSA_OVERRIDE_GFX_VERSION=${{ matrix.gpu_arch }}
          ctest --parallel 4 --output-on-failure
          
      - name: Upload artifacts
        uses: actions/upload-artifact@v3
        if: always()
        with:
          name: build-${{ matrix.gpu_arch }}-${{ matrix.build_type }}
          path: |
            build/bin/*
            build/lib/*.so
'''

with open("examples/workflows/ci.yml", "w") as f:
    f.write(ci_workflow_content)

# Example cluster config
cluster_config_content = '''{
  "kubernetes": {
    "enabled": true,
    "namespace": "amd-ci",
    "kubeconfig_path": "~/.kube/config"
  },
  "slurm": {
    "enabled": false,
    "log_dir": "/shared/logs",
    "modules": ["docker", "rocm"]
  },
  "repositories": [
    {
      "name": "my-rocm-project",
      "url": "https://github.com/myorg/rocm-project.git",
      "branches": ["main", "develop"]
    }
  ],
  "orchestrator": {
    "endpoint": "http://localhost:8000"
  },
  "webhook": {
    "host": "0.0.0.0",
    "port": 8080
  }
}'''

with open("examples/cluster_config.json", "w") as f:
    f.write(cluster_config_content)

print("Example files created!")