# Create remaining files quickly

# job_tracker.py
job_tracker_content = '''"""
Job Tracker - Track workflow and job execution state
"""

import asyncio
import json
import uuid
from datetime import datetime
from typing import Dict, List, Optional
import logging


logger = logging.getLogger(__name__)


class JobTracker:
    def __init__(self, db_config: Dict):
        self.db_config = db_config
        # Simple in-memory storage for now - replace with Redis/PostgreSQL
        self.workflows = {}
        self.jobs = {}
    
    async def create_workflow(self, workflow_id: str, repo_url: str,
                            commit_hash: str, branch: str, event_type: str,
                            workflows: Dict):
        """Create a new workflow execution record"""
        self.workflows[workflow_id] = {
            'id': workflow_id,
            'repo_url': repo_url,
            'commit_hash': commit_hash,
            'branch': branch,
            'event_type': event_type,
            'workflows': workflows,
            'status': 'running',
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'jobs': []
        }
        logger.info(f"Created workflow: {workflow_id}")
    
    async def update_workflow_status(self, workflow_id: str, status: str, error: str = None):
        """Update workflow status"""
        if workflow_id in self.workflows:
            self.workflows[workflow_id]['status'] = status
            self.workflows[workflow_id]['updated_at'] = datetime.now().isoformat()
            if error:
                self.workflows[workflow_id]['error'] = error
    
    async def create_job(self, job_id: str, workflow_id: str, job_spec: Dict):
        """Create a new job execution record"""
        self.jobs[job_id] = {
            'id': job_id,
            'workflow_id': workflow_id,
            'job_name': job_spec['job_name'],
            'matrix_vars': job_spec.get('matrix_vars', {}),
            'container_image': job_spec['container']['image'],
            'status': 'pending',
            'cluster_job_id': None,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'logs': []
        }
        
        # Add job to workflow
        if workflow_id in self.workflows:
            self.workflows[workflow_id]['jobs'].append(job_id)
        
        logger.info(f"Created job: {job_id}")
    
    async def update_job_cluster_id(self, job_id: str, cluster_job_id: str):
        """Update job with cluster job ID"""
        if job_id in self.jobs:
            self.jobs[job_id]['cluster_job_id'] = cluster_job_id
            self.jobs[job_id]['status'] = 'running'
            self.jobs[job_id]['updated_at'] = datetime.now().isoformat()
    
    async def update_job_status(self, job_id: str, status: str, error: str = None):
        """Update job status"""
        if job_id in self.jobs:
            self.jobs[job_id]['status'] = status
            self.jobs[job_id]['updated_at'] = datetime.now().isoformat()
            if error:
                self.jobs[job_id]['error'] = error
    
    def get_workflow_status(self, workflow_id: str) -> Optional[Dict]:
        """Get workflow status and details"""
        return self.workflows.get(workflow_id)
    
    def get_job_status(self, job_id: str) -> Optional[Dict]:
        """Get job status and details"""
        return self.jobs.get(job_id)
    
    def list_recent_workflows(self, limit: int = 50) -> List[Dict]:
        """List recent workflows"""
        workflows = list(self.workflows.values())
        workflows.sort(key=lambda x: x['created_at'], reverse=True)
        return workflows[:limit]
    
    def list_jobs_for_workflow(self, workflow_id: str) -> List[Dict]:
        """List all jobs for a workflow"""
        if workflow_id not in self.workflows:
            return []
        
        job_ids = self.workflows[workflow_id]['jobs']
        return [self.jobs[job_id] for job_id in job_ids if job_id in self.jobs]
'''

with open("amd_ci/monitoring/job_tracker.py", "w") as f:
    f.write(job_tracker_content)

# git_watcher.py
git_watcher_content = '''"""
Git Watcher - Monitor Git repositories for changes and trigger workflows
"""

import asyncio
import aiohttp
import json
from pathlib import Path
from typing import Dict, List
import logging


logger = logging.getLogger(__name__)


class GitWatcher:
    def __init__(self, config: Dict, orchestrator_endpoint: str):
        self.config = config
        self.orchestrator_endpoint = orchestrator_endpoint
        self.repositories = config.get('repositories', [])
    
    async def start_webhook_server(self, host: str = '0.0.0.0', port: int = 8080):
        """Start webhook server to receive Git events"""
        from aiohttp import web
        
        app = web.Application()
        app.router.add_post('/webhook', self.handle_webhook)
        app.router.add_get('/health', self.health_check)
        
        logger.info(f"Starting Git watcher webhook server on {host}:{port}")
        
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, host, port)
        await site.start()
        
        # Keep server running
        while True:
            await asyncio.sleep(1)
    
    async def handle_webhook(self, request):
        """Handle incoming webhook from Git hosting service"""
        from aiohttp import web
        
        try:
            payload = await request.json()
            event_type = request.headers.get('X-GitHub-Event', 'push')
            
            # Extract repository information
            repo_info = self._extract_repo_info(payload, event_type)
            
            if repo_info and self._should_trigger_workflow(repo_info):
                await self._trigger_orchestrator(repo_info, event_type)
                return web.json_response({'status': 'triggered'})
            else:
                return web.json_response({'status': 'ignored'})
        
        except Exception as e:
            logger.error(f"Webhook handling failed: {e}")
            return web.json_response({'status': 'error', 'error': str(e)}, status=500)
    
    async def health_check(self, request):
        """Health check endpoint"""
        from aiohttp import web
        return web.json_response({'status': 'healthy'})
    
    def _extract_repo_info(self, payload: Dict, event_type: str) -> Dict:
        """Extract repository information from webhook payload"""
        repo_info = {}
        
        if event_type == 'push':
            repo_info = {
                'repo_url': payload.get('repository', {}).get('clone_url'),
                'repo_name': payload.get('repository', {}).get('name'),
                'commit_hash': payload.get('after'),
                'branch': payload.get('ref', '').replace('refs/heads/', ''),
                'author': payload.get('head_commit', {}).get('author', {}).get('name')
            }
        elif event_type == 'pull_request':
            pr = payload.get('pull_request', {})
            repo_info = {
                'repo_url': pr.get('head', {}).get('repo', {}).get('clone_url'),
                'repo_name': pr.get('head', {}).get('repo', {}).get('name'),
                'commit_hash': pr.get('head', {}).get('sha'),
                'branch': pr.get('head', {}).get('ref'),
                'pr_number': pr.get('number'),
                'author': pr.get('user', {}).get('login')
            }
        
        return repo_info
    
    def _should_trigger_workflow(self, repo_info: Dict) -> bool:
        """Determine if workflow should be triggered for this repository"""
        repo_url = repo_info.get('repo_url')
        repo_name = repo_info.get('repo_name')
        
        # Check if repository is in our watched list
        for repo_config in self.repositories:
            if (repo_config.get('url') == repo_url or 
                repo_config.get('name') == repo_name):
                
                # Check branch filters
                branch_filters = repo_config.get('branches', [])
                if branch_filters and repo_info.get('branch') not in branch_filters:
                    return False
                
                # Check if .amd directory exists (simplified check)
                return True
        
        return False
    
    async def _trigger_orchestrator(self, repo_info: Dict, event_type: str):
        """Send trigger request to orchestrator"""
        trigger_data = {
            'repo_url': repo_info['repo_url'],
            'commit_hash': repo_info['commit_hash'],
            'branch': repo_info['branch'],
            'event_type': event_type,
            'workflow_path': '.amd/workflows/ci.yml'  # Default workflow
        }
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    f"{self.orchestrator_endpoint}/api/v1/trigger-workflow",
                    json=trigger_data
                ) as response:
                    if response.status == 200:
                        result = await response.json()
                        logger.info(f"Triggered workflow: {result.get('workflow_id')}")
                    else:
                        error = await response.text()
                        logger.error(f"Failed to trigger workflow: {error}")
            except Exception as e:
                logger.error(f"Error contacting orchestrator: {e}")


def main():
    """Main entry point for Git watcher"""
    import sys
    import yaml
    
    if len(sys.argv) != 2:
        print("Usage: amd-ci-watcher <config-file>")
        sys.exit(1)
    
    config_file = sys.argv[1]
    with open(config_file) as f:
        config = yaml.safe_load(f)
    
    orchestrator_endpoint = config.get('orchestrator', {}).get('endpoint', 'http://localhost:8000')
    
    watcher = GitWatcher(config, orchestrator_endpoint)
    
    try:
        asyncio.run(watcher.start_webhook_server(
            host=config.get('webhook', {}).get('host', '0.0.0.0'),
            port=config.get('webhook', {}).get('port', 8080)
        ))
    except KeyboardInterrupt:
        logger.info("Git watcher stopped")
'''

with open("amd_ci/watcher/git_watcher.py", "w") as f:
    f.write(git_watcher_content)

print("Additional core files created!")