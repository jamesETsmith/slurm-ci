# CLI main.py
cli_content = '''#!/usr/bin/env python3
"""
AMD CI CLI - Command line interface for local workflow execution
"""

import argparse
import json
import sys
import asyncio
from pathlib import Path
import logging

from ..core.orchestrator import LocalOrchestrator


def setup_logging(verbose: bool):
    """Setup logging configuration"""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='AMD CI Local Runner - Run workflows locally',
        prog='amd-ci'
    )
    
    parser.add_argument(
        'workflow',
        nargs='?',
        help='Workflow file to run (auto-discovered if not specified)'
    )
    
    parser.add_argument(
        '-d', '--directory',
        default='.',
        help='Working directory (default: current directory)'
    )
    
    parser.add_argument(
        '-m', '--matrix',
        help='Matrix combination as JSON string'
    )
    
    parser.add_argument(
        '--list-workflows',
        action='store_true',
        help='List available workflows'
    )
    
    parser.add_argument(
        '--list-jobs',
        help='List jobs in specified workflow'
    )
    
    parser.add_argument(
        '--job',
        help='Run specific job (default: all jobs)'
    )
    
    parser.add_argument(
        '--execution-mode',
        choices=['local', 'cluster'],
        default='local',
        help='Execution mode: local Docker or remote cluster'
    )
    
    parser.add_argument(
        '--cluster-config',
        help='Path to cluster configuration file'
    )
    
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Show what would be executed without running'
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Verbose output'
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.verbose)
    
    try:
        # Parse matrix combination if provided
        matrix_vars = {}
        if args.matrix:
            matrix_vars = json.loads(args.matrix)
        
        # Initialize orchestrator
        cluster_config = None
        if args.cluster_config:
            with open(args.cluster_config) as f:
                cluster_config = json.load(f)
        
        orchestrator = LocalOrchestrator(
            working_directory=args.directory,
            cluster_config=cluster_config
        )
        
        # Handle different commands
        if args.list_workflows:
            workflows = orchestrator.list_available_workflows()
            print("Available workflows:")
            for workflow in workflows:
                print(f"  {workflow}")
            return
        
        if args.list_jobs:
            jobs = orchestrator.list_workflow_jobs(args.list_jobs)
            print(f"Jobs in {args.list_jobs}:")
            for job in jobs:
                print(f"  {job}")
            return
        
        if args.dry_run:
            print("Dry run mode - showing execution plan:")
            print(f"Working directory: {Path(args.directory).resolve()}")
            print(f"Workflow file: {args.workflow or 'auto-discovered'}")
            print(f"Matrix variables: {matrix_vars or 'auto-generated'}")
            print(f"Execution mode: {args.execution_mode}")
            return
        
        # Execute workflow
        results = orchestrator.execute_local_workflow(
            workflow_file=args.workflow,
            matrix_combination=matrix_vars,
            execution_mode=args.execution_mode
        )
        
        # Report results
        success_count = sum(1 for r in results if r.get('success', False))
        total_count = len(results)
        
        print(f"\\nExecution Summary:")
        print(f"Total jobs: {total_count}")
        print(f"Successful: {success_count}")
        print(f"Failed: {total_count - success_count}")
        
        if success_count == total_count:
            print("✓ All jobs completed successfully")
            sys.exit(0)
        else:
            print("✗ Some jobs failed")
            
            # Show failed jobs
            for i, result in enumerate(results):
                if not result.get('success', False):
                    print(f"  Failed job {i+1}: {result.get('error', 'Unknown error')}")
            
            sys.exit(1)
    
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error parsing matrix JSON: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
'''

with open("amd_ci/cli/main.py", "w") as f:
    f.write(cli_content)

print("CLI main.py created!")