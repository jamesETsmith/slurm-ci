# Write matrix resolver content (fixing the escape issues)
matrix_resolver_content = '''"""
Matrix Resolver - Handle GitHub Actions matrix variable resolution
"""

import re
import os
from typing import Dict, Any


class MatrixResolver:
    def __init__(self):
        self.expression_pattern = re.compile(r'\\$\\{\\{\\s*([^}]+)\\s*\\}\\}')
    
    def resolve_container_image(self, image_template: str, matrix_vars: Dict) -> str:
        """Resolve matrix variables in container image"""
        if not image_template:
            return 'ubuntu:latest'
        
        # Handle GitHub Actions expressions
        resolved_image = self._resolve_expressions(image_template, matrix_vars)
        return resolved_image
    
    def resolve_command(self, command: str, matrix_vars: Dict, env_vars: Dict = None) -> str:
        """Resolve variables in commands"""
        if not command:
            return ''
        
        # Combine matrix vars and env vars
        all_vars = matrix_vars.copy()
        if env_vars:
            all_vars.update({'env': env_vars})
        
        return self._resolve_expressions(command, all_vars)
    
    def _resolve_expressions(self, text: str, context: Dict) -> str:
        """Resolve GitHub Actions expressions"""
        # Simple pattern matching for ${{ matrix.variable }}
        pattern = r'\\$\\{\\{\\s*matrix\\.([\\w_]+)\\s*\\}\\}'
        
        def replace_matrix_var(match):
            var_name = match.group(1)
            return str(context.get(var_name, f'UNDEFINED_{var_name}'))
        
        resolved_text = re.sub(pattern, replace_matrix_var, text)
        
        # Handle env variables
        env_pattern = r'\\$\\{\\{\\s*env\\.([\\w_]+)\\s*\\}\\}'
        
        def replace_env_var(match):
            var_name = match.group(1)
            return str(os.getenv(var_name, f'UNDEFINED_ENV_{var_name}'))
        
        resolved_text = re.sub(env_pattern, replace_env_var, resolved_text)
        
        return resolved_text
    
    def build_matrix_env_vars(self, matrix_vars: Dict) -> Dict[str, str]:
        """Build environment variables from matrix configuration"""
        env_vars = {}
        
        # Add matrix variables with MATRIX_ prefix
        for key, value in matrix_vars.items():
            env_var_name = f'MATRIX_{key.upper()}'
            env_vars[env_var_name] = str(value)
        
        return env_vars
'''

with open("amd_ci/core/matrix_resolver.py", "w") as f:
    f.write(matrix_resolver_content)

print("matrix_resolver.py created (fixed)!")