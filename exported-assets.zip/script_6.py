# Write orchestrator.py
orchestrator_content = '''"""
Main Orchestrator - Central workflow execution coordinator
"""

import asyncio
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging

from .workflow_parser import WorkflowParser
from .matrix_resolver import MatrixResolver
from ..execution.kubernetes_runner import KubernetesJobRunner
from ..execution.slurm_runner import SlurmDockerRunner
from ..execution.local_runner import LocalContainerRunner
from ..monitoring.job_tracker import JobTracker


logger = logging.getLogger(__name__)


class WorkflowOrchestrator:
    """Main orchestrator for Git-based workflow execution"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.workflow_parser = WorkflowParser()
        self.matrix_resolver = MatrixResolver()
        self.job_tracker = JobTracker(config.get('database', {}))
        
        # Initialize execution backends
        self.execution_backends = {}
        
        if config.get('kubernetes', {}).get('enabled', False):
            self.execution_backends['kubernetes'] = KubernetesJobRunner(
                config['kubernetes']
            )
        
        if config.get('slurm', {}).get('enabled', False):
            self.execution_backends['slurm'] = SlurmDockerRunner(
                config['slurm']
            )
    
    async def execute_workflow(self, repo_url: str, workflow_path: str,
                             commit_hash: str, branch: str, 
                             event_type: str = 'push') -> str:
        """Execute workflow from Git repository"""
        
        # Generate unique workflow ID
        workflow_id = str(uuid.uuid4())
        
        logger.info(f"Starting workflow {workflow_id} for {repo_url}@{commit_hash}")
        
        try:
            # Clone repository (in practice, this would be handled by the execution environment)
            # For now, assume workflow file is accessible
            
            # Parse workflow
            self.workflow_parser.load_workflow(workflow_path)
            workflows = self.workflow_parser.extract_workflows()
            
            # Track workflow execution
            await self.job_tracker.create_workflow(
                workflow_id=workflow_id,
                repo_url=repo_url,
                commit_hash=commit_hash,
                branch=branch,
                event_type=event_type,
                workflows=workflows
            )
            
            # Execute each job
            job_results = []
            for job_name, job_config in workflows.items():
                # Generate matrix combinations
                matrix_combinations = self.workflow_parser.generate_matrix_combinations(job_name)
                
                for matrix_vars in matrix_combinations:
                    job_result = await self._execute_single_job(
                        workflow_id=workflow_id,
                        repo_url=repo_url,
                        commit_hash=commit_hash,
                        job_name=job_name,
                        job_config=job_config,
                        matrix_vars=matrix_vars
                    )
                    job_results.append(job_result)
            
            # Update workflow status based on job results
            all_success = all(result.get('success', False) for result in job_results)
            await self.job_tracker.update_workflow_status(
                workflow_id, 'success' if all_success else 'failed'
            )
            
            return workflow_id
            
        except Exception as e:
            logger.error(f"Workflow {workflow_id} failed: {e}")
            await self.job_tracker.update_workflow_status(workflow_id, 'failed', str(e))
            raise
    
    async def _execute_single_job(self, workflow_id: str, repo_url: str,
                                commit_hash: str, job_name: str,
                                job_config: Dict, matrix_vars: Dict) -> Dict:
        """Execute a single job with specific matrix combination"""
        
        job_id = str(uuid.uuid4())
        
        # Resolve container image with matrix variables
        container_spec = job_config['container'].copy()
        container_spec['image'] = self.matrix_resolver.resolve_container_image(
            container_spec['image'], matrix_vars
        )
        
        # Build job specification
        job_spec = {
            'job_id': job_id,
            'workflow_id': workflow_id,
            'repo_url': repo_url,
            'commit_hash': commit_hash,
            'job_name': job_name,
            'container': container_spec,
            'steps': job_config['steps'],
            'matrix_vars': matrix_vars,
            'env': job_config.get('env', {}),
            'timeout_minutes': job_config.get('timeout_minutes', 360)
        }
        
        # Track job
        await self.job_tracker.create_job(job_id, workflow_id, job_spec)
        
        # Determine execution backend
        backend_name = self._select_execution_backend(matrix_vars)
        backend = self.execution_backends[backend_name]
        
        try:
            # Submit job
            cluster_job_id = await backend.submit_job(job_spec)
            await self.job_tracker.update_job_cluster_id(job_id, cluster_job_id)
            
            # Monitor job execution (this would typically be handled asynchronously)
            result = await self._monitor_job_execution(backend, cluster_job_id)
            
            # Update job status
            status = 'success' if result.get('success', False) else 'failed'
            await self.job_tracker.update_job_status(job_id, status)
            
            return {'job_id': job_id, 'success': result.get('success', False)}
            
        except Exception as e:
            logger.error(f"Job {job_id} failed: {e}")
            await self.job_tracker.update_job_status(job_id, 'failed', str(e))
            return {'job_id': job_id, 'success': False, 'error': str(e)}
    
    def _select_execution_backend(self, matrix_vars: Dict) -> str:
        """Select appropriate execution backend based on requirements"""
        # Simple selection logic - can be made more sophisticated
        if 'kubernetes' in self.execution_backends:
            return 'kubernetes'
        elif 'slurm' in self.execution_backends:
            return 'slurm'
        else:
            raise RuntimeError("No execution backends available")
    
    async def _monitor_job_execution(self, backend, cluster_job_id: str) -> Dict:
        """Monitor job execution (simplified)"""
        # In a real implementation, this would poll the backend for status
        # For now, return a placeholder result
        return {'success': True, 'exit_code': 0}


class LocalOrchestrator:
    """Orchestrator for local workflow execution"""
    
    def __init__(self, working_directory: str, cluster_config: Dict = None):
        self.working_dir = Path(working_directory).resolve()
        self.workflow_parser = WorkflowParser()
        self.matrix_resolver = MatrixResolver()
        self.local_runner = LocalContainerRunner()
        
        self.use_cluster = cluster_config is not None
        if self.use_cluster:
            if cluster_config.get('kubernetes', {}).get('enabled'):
                self.cluster_runner = KubernetesJobRunner(cluster_config['kubernetes'])
            elif cluster_config.get('slurm', {}).get('enabled'):
                self.cluster_runner = SlurmDockerRunner(cluster_config['slurm'])
    
    def execute_local_workflow(self, workflow_file: str = None,
                             matrix_combination: Dict = None,
                             execution_mode: str = "local") -> List[Dict]:
        """Execute workflow from local working directory"""
        
        # Auto-discover workflow file if not specified
        if not workflow_file:
            workflow_file = self._discover_workflow_file()
        
        workflow_path = self.working_dir / workflow_file
        if not workflow_path.exists():
            raise FileNotFoundError(f"Workflow file not found: {workflow_path}")
        
        # Parse workflow
        self.workflow_parser.load_workflow(str(workflow_path))
        workflows = self.workflow_parser.extract_workflows()
        
        # Generate matrix combinations
        if not matrix_combination:
            all_combinations = []
            for job_name in workflows.keys():
                job_combinations = self.workflow_parser.generate_matrix_combinations(job_name)
                all_combinations.extend([(job_name, combo) for combo in job_combinations])
        else:
            all_combinations = [(list(workflows.keys())[0], matrix_combination)]
        
        # Execute workflows
        results = []
        for job_name, matrix_vars in all_combinations:
            job_config = workflows[job_name]
            
            if execution_mode == "local":
                result = self._execute_locally(job_name, job_config, matrix_vars)
            elif execution_mode == "cluster":
                result = self._execute_on_cluster(job_name, job_config, matrix_vars)
            else:
                raise ValueError(f"Unknown execution mode: {execution_mode}")
            
            results.append(result)
        
        return results
    
    def _execute_locally(self, job_name: str, job_config: Dict, matrix_vars: Dict) -> Dict:
        """Execute job locally using Docker"""
        container_spec = job_config['container'].copy()
        container_spec['image'] = self.matrix_resolver.resolve_container_image(
            container_spec['image'], matrix_vars
        )
        
        job_spec = {
            'job_name': job_name,
            'container': container_spec,
            'steps': job_config['steps'],
            'matrix_vars': matrix_vars,
            'env': job_config.get('env', {})
        }
        
        return self.local_runner.run_workflow_locally(job_spec, self.working_dir, matrix_vars)
    
    def _execute_on_cluster(self, job_name: str, job_config: Dict, matrix_vars: Dict) -> Dict:
        """Execute job on cluster"""
        if not self.use_cluster:
            raise RuntimeError("Cluster execution not configured")
        
        # Implementation would be similar to WorkflowOrchestrator._execute_single_job
        # but adapted for local context
        return {'success': True, 'message': 'Cluster execution not fully implemented'}
    
    def _discover_workflow_file(self) -> str:
        """Auto-discover workflow files in working directory"""
        workflow_paths = [
            ".amd/workflows/ci.yml",
            ".amd/workflows/main.yml",
            ".github/workflows/ci.yml", 
            ".github/workflows/main.yml"
        ]
        
        for path in workflow_paths:
            if (self.working_dir / path).exists():
                return path
        
        # Look for any .yml files in workflow directories
        for workflow_dir in [".amd/workflows", ".github/workflows"]:
            workflow_dir_path = self.working_dir / workflow_dir
            if workflow_dir_path.exists():
                yml_files = list(workflow_dir_path.glob("*.yml"))
                if yml_files:
                    return str(yml_files[0].relative_to(self.working_dir))
        
        raise FileNotFoundError("No workflow files found in working directory")
    
    def list_available_workflows(self) -> List[str]:
        """List available workflow files"""
        workflow_files = []
        for workflow_dir in [".amd/workflows", ".github/workflows"]:
            workflow_dir_path = self.working_dir / workflow_dir
            if workflow_dir_path.exists():
                for yml_file in workflow_dir_path.glob("*.yml"):
                    workflow_files.append(str(yml_file.relative_to(self.working_dir)))
        return workflow_files
    
    def list_workflow_jobs(self, workflow_file: str) -> List[str]:
        """List jobs in a specific workflow"""
        workflow_path = self.working_dir / workflow_file
        if not workflow_path.exists():
            return []
        
        parser = WorkflowParser(str(workflow_path))
        workflows = parser.extract_workflows()
        return list(workflows.keys())
'''

with open("amd_ci/core/orchestrator.py", "w") as f:
    f.write(orchestrator_content)

print("orchestrator.py created!")