# AMD CI - Distributed GPU CI/CD System

A GitHub Actions compatible CI/CD system designed specifically for AMD GPU workloads and cluster environments.

## Features

- **GitHub Actions Compatible**: Uses exact same YAML syntax as GitHub Actions
- **GPU-Aware Scheduling**: Automatically schedules jobs on appropriate GPU architectures
- **Matrix Builds**: Full support for matrix strategies with include/exclude rules
- **Multiple Execution Backends**: 
  - Local Docker execution for development
  - Kubernetes Jobs for cloud environments  
  - Slurm integration for HPC clusters
- **Real-time Monitoring**: Job status tracking and log streaming
- **Git Integration**: Webhook-based triggers from Git repositories
- **Local Development**: Run workflows locally without Git commits

## Quick Start

### Installation

```bash
pip install -e .

# Install optional dependencies
pip install -e ".[kubernetes]"  # For Kubernetes support
pip install -e ".[dashboard]"   # For web dashboard
```

### Local Usage

Run a workflow in your current directory:

```bash
# Auto-discover and run workflow
amd-ci

# Run specific workflow
amd-ci .amd/workflows/ci.yml

# Run with specific matrix combination
amd-ci --matrix '{"gpu_arch": "gfx90a", "rocm_version": "5.7.0"}'

# List available workflows
amd-ci --list-workflows

# Dry run to see execution plan
amd-ci --dry-run
```

### Workflow Configuration

Create `.amd/workflows/ci.yml`:

```yaml
name: AMD GPU CI Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  build-and-test:
    runs-on: self-hosted
    container:
      image: rocm/dev-ubuntu-22.04:${{ matrix.rocm_version }}

    strategy:
      matrix:
        gpu_arch: [gfx908, gfx90a, gfx1030]
        rocm_version: [5.6.0, 5.7.0]
        build_type: [Release, Debug]

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Setup environment
        run: |
          apt-get update && apt-get install -y build-essential cmake

      - name: Build project
        run: |
          cmake -S . -B build -DCMAKE_BUILD_TYPE=${{ matrix.build_type }}
          cmake --build build --parallel

      - name: Run tests  
        run: |
          cd build
          export HSA_OVERRIDE_GFX_VERSION=${{ matrix.gpu_arch }}
          ctest --parallel 4
```

## Architecture

### Core Components

- **WorkflowParser**: Parses GitHub Actions YAML workflows
- **MatrixResolver**: Handles matrix variable resolution and expressions
- **Orchestrator**: Central workflow execution coordinator
- **Execution Backends**: 
  - `KubernetesJobRunner`: Execute jobs as Kubernetes Jobs
  - `SlurmDockerRunner`: Execute jobs on Slurm clusters
  - `LocalContainerRunner`: Execute jobs locally with Docker
- **GitWatcher**: Monitor repositories for changes via webhooks
- **JobTracker**: Track workflow and job execution state

### Execution Flow

1. **Trigger**: Git webhook or manual trigger
2. **Parse**: Extract workflow configuration and matrix
3. **Schedule**: Determine appropriate execution backend
4. **Execute**: Run containerized jobs on target infrastructure
5. **Monitor**: Track progress and collect results
6. **Report**: Aggregate results and artifacts

## Cluster Setup

### Kubernetes

```bash
# Install with Kubernetes support
pip install -e ".[kubernetes]"

# Configure cluster access
export KUBECONFIG=/path/to/kubeconfig

# Create namespace
kubectl create namespace amd-ci

# Deploy AMD GPU device plugin (if using AMD GPUs)
kubectl apply -f https://raw.githubusercontent.com/ROCm-Developer-Tools/k8s-device-plugin/master/amd-gpu-device-plugin.yaml
```

### Slurm

Configure Slurm integration in `cluster_config.json`:

```json
{
  "slurm": {
    "enabled": true,
    "log_dir": "/shared/logs", 
    "modules": ["docker", "rocm"]
  }
}
```

## Development

### Project Structure

```
amd_ci/
├── core/                 # Core orchestration logic
│   ├── orchestrator.py   # Main workflow coordinator
│   ├── workflow_parser.py# GitHub Actions YAML parser
│   └── matrix_resolver.py# Matrix variable resolution
├── execution/            # Execution backends
│   ├── kubernetes_runner.py
│   ├── slurm_runner.py
│   └── local_runner.py
├── monitoring/           # Job tracking and monitoring
├── watcher/              # Git repository monitoring
└── cli/                  # Command line interface
```

### Running Tests

```bash
pytest tests/
```

### Development Installation

```bash
git clone <repo-url>
cd amd-ci
pip install -e ".[dev]"
```

## Configuration

### Workflow Configuration

Workflows use standard GitHub Actions syntax with AMD-specific enhancements:

- **GPU Architecture Targeting**: Specify `gpu_arch` in matrix for GPU selection
- **ROCm Version Matrix**: Test across multiple ROCm versions
- **Container Images**: Use ROCm-enabled containers automatically
- **Resource Requirements**: Specify GPU, CPU, and memory requirements

### Matrix Strategies

```yaml
strategy:
  matrix:
    gpu_arch: [gfx908, gfx90a, gfx1030, gfx1100]
    rocm_version: [5.6.0, 5.7.0]
    build_type: [Release, Debug]
    exclude:
      - gpu_arch: gfx1030
        build_type: Debug
    include:
      - gpu_arch: gfx90a
        rocm_version: 5.7.0
        build_type: Release
        tags: [nightly, benchmark]
```

### Cluster Configuration

```json
{
  "kubernetes": {
    "enabled": true,
    "namespace": "amd-ci",
    "node_selector": {
      "gpu.amd.com/chip": "gfx90a"
    }
  },
  "slurm": {
    "enabled": false,
    "partition": "gpu",
    "account": "amd-ci"
  }
}
```

## Monitoring and Dashboards

### Job Status API

```bash
# Get workflow status
curl http://localhost:8000/api/v1/workflows/{workflow_id}/status

# Get job logs
curl http://localhost:8000/api/v1/jobs/{job_id}/logs
```

### Web Dashboard

```bash
# Start dashboard
amd-ci-dashboard --port 8080

# Visit http://localhost:8080
```

## Examples

See the `examples/` directory for:

- Sample workflow configurations
- Cluster configuration templates
- Integration examples

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes with tests
4. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

- GitHub Issues for bug reports
- Documentation at [link]
- Community discussions at [link]
