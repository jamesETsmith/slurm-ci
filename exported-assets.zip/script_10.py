# local_runner.py
local_runner_content = '''"""
Local Container Runner - Execute workflows locally using Docker
"""

import docker
import tempfile
import subprocess
from pathlib import Path
from typing import Dict
import logging


logger = logging.getLogger(__name__)


class LocalContainerRunner:
    def __init__(self):
        try:
            self.docker_client = docker.from_env()
        except Exception as e:
            logger.warning(f"Docker client initialization failed: {e}")
            self.docker_client = None
    
    def run_workflow_locally(self, job_spec: Dict, working_dir: Path, 
                           matrix_vars: Dict) -> Dict:
        """Run workflow directly on local machine using Docker"""
        
        if not self.docker_client:
            raise RuntimeError("Docker client not available")
        
        container_spec = job_spec['container']
        resolved_image = container_spec['image']
        
        # Pull image if needed
        self._ensure_image_available(resolved_image)
        
        # Create temporary script with all workflow steps
        script_content = self._build_workflow_script(job_spec, matrix_vars)
        
        # Run container with working directory mounted
        container_config = {
            'image': resolved_image,
            'command': ['bash', '/tmp/workflow_script.sh'],
            'volumes': {
                str(working_dir): {'bind': '/workspace', 'mode': 'rw'}
            },
            'working_dir': '/workspace',
            'environment': self._build_environment_vars(job_spec, matrix_vars),
            'remove': True,  # Auto-remove container when done
            'stdout': True,
            'stderr': True,
            'stream': True
        }
        
        # Add GPU support if available
        if self._has_gpu_support():
            container_config['device_requests'] = [
                docker.types.DeviceRequest(count=-1, capabilities=[['gpu']])
            ]
        
        # Write script to temp file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as f:
            f.write(script_content)
            temp_script = f.name
        
        try:
            # Copy script to a location the container can access
            script_dest = working_dir / 'workflow_script.sh'
            script_dest.write_text(script_content)
            script_dest.chmod(0o755)
            
            # Update container config to use the mounted script
            container_config['command'] = ['bash', '/workspace/workflow_script.sh']
            
            print(f"Running workflow in container: {resolved_image}")
            print(f"Working directory: {working_dir}")
            print(f"Matrix variables: {matrix_vars}")
            
            # Run container
            container = self.docker_client.containers.run(**container_config)
            
            # Stream output in real-time
            output_lines = []
            for line in container:
                line_str = line.decode('utf-8')
                print(line_str, end='')
                output_lines.append(line_str)
            
            # Get final container state
            container.reload()
            exit_code = container.attrs['State']['ExitCode']
            
            return {
                'success': exit_code == 0,
                'exit_code': exit_code,
                'output': ''.join(output_lines)
            }
            
        except Exception as e:
            logger.error(f"Container execution failed: {e}")
            return {
                'success': False,
                'exit_code': -1,
                'error': str(e)
            }
        finally:
            # Clean up temp files
            Path(temp_script).unlink(missing_ok=True)
            (working_dir / 'workflow_script.sh').unlink(missing_ok=True)
    
    def _build_workflow_script(self, job_spec: Dict, matrix_vars: Dict) -> str:
        """Build executable script from workflow steps"""
        script_lines = [
            '#!/bin/bash',
            'set -e  # Exit on any error',
            'set -x  # Print commands as they execute',
            '',
            '# Matrix and environment variables',
        ]
        
        # Add matrix variables
        for key, value in matrix_vars.items():
            script_lines.append(f'export MATRIX_{key.upper()}="{value}"')
        
        script_lines.extend([
            '',
            '# GitHub Actions compatible variables',
            'export GITHUB_WORKSPACE="/workspace"',
            'export GITHUB_ACTIONS="true"',
            'export CI="true"',
            '',
            '# Workflow execution'
        ])
        
        # Add each workflow step
        for i, step in enumerate(job_spec['steps']):
            step_name = step.get('name', f'Step {i+1}')
            script_lines.extend([
                f'',
                f'echo "::group::{step_name}"',
                f'echo "Running: {step_name}"',
                f'',
                step['run'],
                f'',
                f'echo "::endgroup::"',
                f'echo "✓ {step_name} completed successfully"'
            ])
        
        return '\\n'.join(script_lines)
    
    def _build_environment_vars(self, job_spec: Dict, matrix_vars: Dict) -> Dict[str, str]:
        """Build environment variables for container"""
        env_vars = {
            'CI': 'true',
            'GITHUB_ACTIONS': 'true',
            'GITHUB_WORKSPACE': '/workspace'
        }
        
        # Add job environment variables
        env_vars.update(job_spec.get('env', {}))
        
        # Add matrix variables
        for key, value in matrix_vars.items():
            env_vars[f'MATRIX_{key.upper()}'] = str(value)
        
        return env_vars
    
    def _ensure_image_available(self, image: str):
        """Ensure Docker image is available locally"""
        try:
            self.docker_client.images.get(image)
            logger.info(f"Image {image} already available locally")
        except docker.errors.ImageNotFound:
            logger.info(f"Pulling image: {image}")
            try:
                self.docker_client.images.pull(image)
            except Exception as e:
                raise RuntimeError(f"Failed to pull image {image}: {e}")
    
    def _has_gpu_support(self) -> bool:
        """Check if GPU support is available"""
        try:
            # Try to run nvidia-smi or rocm-smi
            result = subprocess.run(['nvidia-smi'], capture_output=True)
            if result.returncode == 0:
                return True
            
            result = subprocess.run(['rocm-smi'], capture_output=True)
            if result.returncode == 0:
                return True
                
            return False
        except FileNotFoundError:
            return False
    
    def list_available_images(self) -> list:
        """List locally available Docker images"""
        if not self.docker_client:
            return []
        
        images = self.docker_client.images.list()
        return [img.tags[0] if img.tags else img.id for img in images]
'''

with open("amd_ci/execution/local_runner.py", "w") as f:
    f.write(local_runner_content)

print("local_runner.py created!")