# Create the remaining __init__.py files for modules
init_files = {
    "amd_ci/core/__init__.py": '''"""
Core orchestration components
"""

from .orchestrator import WorkflowOrchestrator, LocalOrchestrator
from .workflow_parser import WorkflowParser  
from .matrix_resolver import MatrixResolver

__all__ = [
    "WorkflowOrchestrator",
    "LocalOrchestrator", 
    "WorkflowParser",
    "MatrixResolver",
]
''',

    "amd_ci/execution/__init__.py": '''"""
Workflow execution backends
"""

from .kubernetes_runner import KubernetesJobRunner
from .slurm_runner import SlurmDockerRunner
from .local_runner import LocalContainerRunner

__all__ = [
    "KubernetesJobRunner",
    "SlurmDockerRunner", 
    "LocalContainerRunner",
]
''',

    "amd_ci/monitoring/__init__.py": '''"""
Job monitoring and tracking
"""

from .job_tracker import JobTracker

__all__ = [
    "JobTracker",
]
''',

    "amd_ci/watcher/__init__.py": '''"""
Git repository monitoring
"""

from .git_watcher import GitWatcher

__all__ = [
    "GitWatcher",
]
''',

    "amd_ci/cli/__init__.py": '''"""
Command line interface
"""
''',

    "amd_ci/config/__init__.py": '''"""
Configuration management
"""
'''
}

for file_path, content in init_files.items():
    with open(file_path, "w") as f:
        f.write(content)

print("All __init__.py files created!")

# Create a simple settings.py
settings_content = '''"""
Configuration settings and defaults
"""

import os
from pathlib import Path

# Default configuration
DEFAULT_CONFIG = {
    "execution": {
        "default_backend": "local",
        "timeout_minutes": 360,
        "max_parallel_jobs": 10
    },
    "container": {
        "default_image": "ubuntu:22.04",
        "docker_socket": "/var/run/docker.sock",
        "pull_policy": "always"
    },
    "logging": {
        "level": "INFO",
        "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    },
    "directories": {
        "workflow_dirs": [".amd/workflows", ".github/workflows"],
        "log_dir": "logs",
        "artifact_dir": "artifacts"
    }
}

# Environment variable overrides
def get_config_value(key_path: str, default=None):
    """Get configuration value with environment variable override"""
    env_key = f"AMD_CI_{key_path.replace('.', '_').upper()}"
    return os.getenv(env_key, default)

# Common paths
HOME_DIR = Path.home()
CONFIG_DIR = HOME_DIR / ".amd-ci"
CACHE_DIR = CONFIG_DIR / "cache"
LOG_DIR = CONFIG_DIR / "logs"

# Create config directories
CONFIG_DIR.mkdir(exist_ok=True)
CACHE_DIR.mkdir(exist_ok=True) 
LOG_DIR.mkdir(exist_ok=True)
'''

with open("amd_ci/config/settings.py", "w") as f:
    f.write(settings_content)

print("settings.py created!")