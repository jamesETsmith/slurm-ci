# Fix the slurm_runner.py with proper escaping
slurm_runner_content = '''"""
Slurm Docker Runner - Execute workflows on Slurm cluster with Docker
"""

import subprocess
import tempfile
from pathlib import Path
from typing import Dict
import logging


logger = logging.getLogger(__name__)


class SlurmDockerRunner:
    def __init__(self, slurm_config: Dict):
        self.config = slurm_config
    
    async def submit_job(self, job_spec: Dict) -> str:
        """Submit workflow as Slurm job with Docker container"""
        
        matrix_vars = job_spec.get('matrix_vars', {})
        
        # Generate Slurm script
        slurm_script = self._generate_slurm_script(job_spec)
        
        # Write script to temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as f:
            f.write(slurm_script)
            script_path = f.name
        
        Path(script_path).chmod(0o755)
        
        try:
            # Submit to Slurm
            cmd = [
                'sbatch',
                '--parsable',  # Return job ID
                f'--job-name=ci-{job_spec["job_name"]}-{job_spec["job_id"][:8]}',
                f'--nodes=1',
                f'--ntasks=1',
                f'--cpus-per-task={job_spec.get("cpu_count", 8)}',
                f'--mem={job_spec.get("memory_gb", 16)}G',
                f'--time={job_spec.get("timeout_minutes", 120)}',
                script_path
            ]
            
            # Add GPU requirements
            if 'gpu_arch' in matrix_vars:
                cmd.extend([f'--gres=gpu:{matrix_vars["gpu_arch"]}:1'])
            
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            slurm_job_id = result.stdout.strip()
            
            logger.info(f"Submitted Slurm job: {slurm_job_id}")
            return slurm_job_id
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to submit Slurm job: {e.stderr}")
            raise RuntimeError(f"Slurm submission failed: {e.stderr}")
        finally:
            # Clean up script file
            Path(script_path).unlink(missing_ok=True)
    
    def _generate_slurm_script(self, job_spec: Dict) -> str:
        """Generate Slurm batch script with Docker execution"""
        
        container_spec = job_spec['container']
        docker_image = container_spec['image']
        matrix_vars = job_spec.get('matrix_vars', {})
        
        # Generate workflow execution script
        workflow_script = self._build_workflow_script(job_spec)
        
        log_dir = self.config.get("log_dir", "logs")
        commit_hash = job_spec.get('commit_hash', '')
        branch = job_spec.get('branch', '')
        repo_url = job_spec['repo_url']
        gpu_arch = matrix_vars.get('gpu_arch', '')
        
        slurm_script = f"""#!/bin/bash
#SBATCH --output={log_dir}/%j.out
#SBATCH --error={log_dir}/%j.err

set -e

# Load required modules
{self._get_module_loads()}

# Set up workspace
export GITHUB_WORKSPACE=$SLURM_SUBMIT_DIR
export GITHUB_SHA={commit_hash}
export GITHUB_REF={branch}

# Set GPU environment
export HSA_OVERRIDE_GFX_VERSION={gpu_arch}

# Clone repository if needed
if [ ! -d ".git" ]; then
    git clone {repo_url} .
    git checkout {commit_hash}
fi

# Pull Docker image
docker pull {docker_image}

# Create workflow script
cat << 'WORKFLOW_SCRIPT_EOF' > /tmp/workflow_script_${{SLURM_JOB_ID}}.sh
{workflow_script}
WORKFLOW_SCRIPT_EOF

chmod +x /tmp/workflow_script_${{SLURM_JOB_ID}}.sh

# Run container with workflow script
docker run --rm --gpus all --network host \\
    -v $SLURM_SUBMIT_DIR:/workspace -w /workspace \\
    -e GITHUB_WORKSPACE=/workspace \\
    -e GITHUB_SHA={commit_hash} \\
    -e GITHUB_REF={branch} \\
    -e CI=true \\
    -e GITHUB_ACTIONS=true \\
    {self._build_matrix_env_args(matrix_vars)} \\
    {docker_image} bash /tmp/workflow_script_${{SLURM_JOB_ID}}.sh

echo "Workflow completed successfully"

# Cleanup
rm -f /tmp/workflow_script_${{SLURM_JOB_ID}}.sh
"""
        
        return slurm_script
    
    def _build_workflow_script(self, job_spec: Dict) -> str:
        """Build the workflow execution script"""
        lines = [
            '#!/bin/bash',
            'set -e',
            'set -x',
            '',
            '# Workflow Steps'
        ]
        
        for i, step in enumerate(job_spec['steps']):
            step_name = step.get('name', f'Step {i+1}')
            lines.extend([
                f'',
                f'echo "::group::{step_name}"',
                f'echo "=== Running step: {step_name} ==="',
                step['run'],
                f'echo "=== Step {step_name} completed ==="',
                f'echo "::endgroup::"',
                ''
            ])
        
        return '\\n'.join(lines)
    
    def _build_matrix_env_args(self, matrix_vars: Dict) -> str:
        """Build Docker environment arguments for matrix variables"""
        env_args = []
        for key, value in matrix_vars.items():
            env_args.append(f'-e MATRIX_{key.upper()}={value}')
        return ' '.join(env_args)
    
    def _get_module_loads(self) -> str:
        """Get module load commands for Slurm"""
        modules = self.config.get('modules', ['docker'])
        if modules:
            return '\\n'.join([f'module load {module}' for module in modules])
        return ''
    
    async def get_job_status(self, job_id: str) -> Dict:
        """Get Slurm job status"""
        try:
            cmd = ['squeue', '-j', job_id, '--format=%T', '--noheader']
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            
            if result.stdout.strip():
                slurm_state = result.stdout.strip()
                # Map Slurm states to our states
                status_map = {
                    'RUNNING': 'running',
                    'PENDING': 'pending', 
                    'COMPLETED': 'success',
                    'FAILED': 'failed',
                    'CANCELLED': 'cancelled',
                    'TIMEOUT': 'failed'
                }
                status = status_map.get(slurm_state, 'unknown')
            else:
                # Job not in queue, check if completed
                cmd = ['sacct', '-j', job_id, '--format=State', '--noheader', '--parsable2']
                result = subprocess.run(cmd, capture_output=True, text=True)
                if result.returncode == 0 and result.stdout.strip():
                    slurm_state = result.stdout.strip().split('|')[0]
                    status = 'success' if slurm_state == 'COMPLETED' else 'failed'
                else:
                    status = 'unknown'
            
            return {'status': status, 'slurm_state': slurm_state}
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to get job status: {e}")
            return {'status': 'unknown', 'error': str(e)}
'''

with open("amd_ci/execution/slurm_runner.py", "w") as f:
    f.write(slurm_runner_content)

print("slurm_runner.py created (fixed)!")