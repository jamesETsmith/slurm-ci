# Write core module files

# workflow_parser.py
workflow_parser_content = '''"""
Workflow Parser - Parse GitHub Actions compatible YAML workflows
"""

import yaml
import itertools
from typing import Dict, List, Optional, Any
from pathlib import Path


class WorkflowParser:
    def __init__(self, workflow_path: Optional[str] = None):
        self.workflow = None
        if workflow_path:
            self.load_workflow(workflow_path)
    
    def load_workflow(self, workflow_path: str):
        """Load workflow from YAML file"""
        with open(workflow_path, 'r') as f:
            self.workflow = yaml.safe_load(f)
    
    def extract_container_specs(self) -> List[Dict]:
        """Extract all container specifications from workflow"""
        if not self.workflow:
            return []
        
        containers = []
        
        for job_name, job_config in self.workflow.get('jobs', {}).items():
            # Job-level container
            if 'container' in job_config:
                container_spec = self._parse_container_config(
                    job_config['container'], job_name
                )
                containers.append(container_spec)
            
            # Step-level containers (Docker actions)
            for step in job_config.get('steps', []):
                if step.get('uses', '').startswith('docker://'):
                    containers.append({
                        'image': step['uses'][9:],  # Remove 'docker://'
                        'job': job_name,
                        'step': step.get('name', 'unnamed')
                    })
        
        return containers
    
    def _parse_container_config(self, container_config: Any, job_name: str) -> Dict:
        """Parse container configuration (string or object)"""
        if isinstance(container_config, str):
            return {
                'image': container_config,
                'job': job_name,
                'env': {},
                'volumes': [],
                'ports': [],
                'options': ''
            }
        else:
            return {
                'image': container_config.get('image'),
                'job': job_name,
                'env': container_config.get('env', {}),
                'volumes': container_config.get('volumes', []),
                'ports': container_config.get('ports', []),
                'options': container_config.get('options', '')
            }
    
    def extract_matrix_config(self, job_name: str) -> Dict:
        """Extract matrix configuration for a specific job"""
        if not self.workflow:
            return {}
        
        job_config = self.workflow.get('jobs', {}).get(job_name, {})
        strategy = job_config.get('strategy', {})
        return strategy.get('matrix', {})
    
    def generate_matrix_combinations(self, job_name: str = None) -> List[Dict]:
        """Generate all matrix combinations for workflow or specific job"""
        if not self.workflow:
            return [{}]
        
        all_combinations = []
        
        jobs_to_process = {}
        if job_name:
            if job_name in self.workflow.get('jobs', {}):
                jobs_to_process[job_name] = self.workflow['jobs'][job_name]
        else:
            jobs_to_process = self.workflow.get('jobs', {})
        
        for job_name, job_config in jobs_to_process.items():
            strategy = job_config.get('strategy', {})
            matrix = strategy.get('matrix', {})
            
            if not matrix:
                all_combinations.append({})
                continue
            
            # Extract matrix dimensions
            matrix_vars = {}
            include_combinations = matrix.pop('include', [])
            exclude_combinations = matrix.pop('exclude', [])
            
            # Build base matrix
            for key, values in matrix.items():
                if isinstance(values, list):
                    matrix_vars[key] = values
                else:
                    matrix_vars[key] = [values]
            
            if matrix_vars:
                # Generate cartesian product of matrix variables
                keys = list(matrix_vars.keys())
                value_combinations = list(itertools.product(*[matrix_vars[k] for k in keys]))
                
                combinations = []
                for combo in value_combinations:
                    combination = dict(zip(keys, combo))
                    
                    # Check if combination should be excluded
                    if not self._should_exclude_combination(combination, exclude_combinations):
                        combinations.append(combination)
                
                # Add include combinations
                combinations.extend(include_combinations)
                all_combinations.extend(combinations)
            else:
                # Add include combinations even if no base matrix
                if include_combinations:
                    all_combinations.extend(include_combinations)
                else:
                    all_combinations.append({})
        
        return all_combinations if all_combinations else [{}]
    
    def _should_exclude_combination(self, combination: Dict, excludes: List[Dict]) -> bool:
        """Check if a combination should be excluded"""
        for exclude_rule in excludes:
            matches = True
            for key, value in exclude_rule.items():
                if key in ['reason']:  # Skip metadata keys
                    continue
                if key not in combination:
                    matches = False
                    break
                
                # Handle array values in exclude rules
                if isinstance(value, list):
                    if combination[key] not in value:
                        matches = False
                        break
                else:
                    if combination[key] != value:
                        matches = False
                        break
            
            if matches:
                return True
        
        return False
    
    def extract_job_steps(self, job_name: str) -> List[Dict]:
        """Extract steps for a specific job"""
        if not self.workflow:
            return []
        
        job_config = self.workflow.get('jobs', {}).get(job_name, {})
        return job_config.get('steps', [])
    
    def extract_workflows(self) -> Dict:
        """Extract complete workflow information"""
        if not self.workflow:
            return {}
        
        workflows = {}
        
        for job_name, job_config in self.workflow.get('jobs', {}).items():
            workflows[job_name] = {
                'name': job_name,
                'runs_on': job_config.get('runs-on', 'self-hosted'),
                'container': self._parse_container_config(
                    job_config.get('container', 'ubuntu:latest'), job_name
                ),
                'steps': job_config.get('steps', []),
                'matrix': self.extract_matrix_config(job_name),
                'env': job_config.get('env', {}),
                'timeout_minutes': job_config.get('timeout-minutes', 360),
                'strategy': job_config.get('strategy', {}),
                'if': job_config.get('if', 'true'),
                'needs': job_config.get('needs', [])
            }
        
        return workflows
'''

with open("amd_ci/core/workflow_parser.py", "w") as f:
    f.write(workflow_parser_content)

print("workflow_parser.py created!")