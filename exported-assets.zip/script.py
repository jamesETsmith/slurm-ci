# Create the package structure and generate all the source files
import os
from pathlib import Path

# Create the package directory structure
package_name = "amd_ci"
structure = {
    package_name: {
        "__init__.py": "",
        "core": {
            "__init__.py": "",
            "orchestrator.py": "",
            "workflow_parser.py": "",
            "matrix_resolver.py": "",
        },
        "execution": {
            "__init__.py": "",
            "kubernetes_runner.py": "",
            "slurm_runner.py": "",
            "local_runner.py": "",
            "container_runner.py": "",
        },
        "monitoring": {
            "__init__.py": "",
            "job_tracker.py": "",
            "dashboard.py": "",
        },
        "watcher": {
            "__init__.py": "",
            "git_watcher.py": "",
        },
        "cli": {
            "__init__.py": "",
            "main.py": "",
        },
        "config": {
            "__init__.py": "",
            "settings.py": "",
        }
    },
    "setup.py": "",
    "requirements.txt": "",
    "README.md": "",
    "examples": {
        "workflows": {
            "ci.yml": "",
            "pr.yml": "",
            "nightly.yml": "",
        },
        "cluster_config.json": "",
    }
}

def create_structure(base_path, structure):
    for name, content in structure.items():
        path = Path(base_path) / name
        if isinstance(content, dict):
            path.mkdir(parents=True, exist_ok=True)
            create_structure(path, content)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            # We'll populate the files with actual content next
            path.touch()

create_structure(".", structure)
print("Package structure created successfully!")

# List the created structure
def show_tree(path, prefix="", max_depth=3, current_depth=0):
    if current_depth >= max_depth:
        return
    
    items = list(Path(path).iterdir())
    items.sort(key=lambda x: (x.is_file(), x.name))
    
    for i, item in enumerate(items):
        is_last = i == len(items) - 1
        current_prefix = "└── " if is_last else "├── "
        print(f"{prefix}{current_prefix}{item.name}")
        
        if item.is_dir() and current_depth < max_depth - 1:
            extension_prefix = "    " if is_last else "│   "
            show_tree(item, prefix + extension_prefix, max_depth, current_depth + 1)

print("\nPackage structure:")
show_tree(package_name)